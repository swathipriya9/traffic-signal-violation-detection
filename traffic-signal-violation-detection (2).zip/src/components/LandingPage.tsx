import React from 'react';
import { motion } from 'motion/react';
import { Shield, Radio, Activity, Eye } from 'lucide-react';

interface LandingPageProps {
  onNext: () => void;
}

export default function LandingPage({ onNext }: LandingPageProps) {
  return (
    <div id="landing-container" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-6 sm:p-12 relative overflow-hidden select-none">
      
      {/* Background visual graphics */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-20">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-red-600 blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-[30rem] h-[30rem] rounded-full bg-emerald-600 blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40rem] h-px bg-gradient-to-r from-transparent via-emerald-500 to-transparent rotate-12"></div>
        <div className="absolute top-1/3 left-1/2 -translate-x-1/12 -translate-y-1/2 w-[35rem] h-px bg-gradient-to-r from-transparent via-red-500 to-transparent -rotate-12"></div>
      </div>

      {/* Grid Pattern overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30 pointer-events-none"></div>

      {/* Header University Seals */}
      <header id="landing-header" className="z-10 flex justify-center items-center w-full max-w-6xl mx-auto border-b border-slate-900 pb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-900/40">
            <Shield className="w-6 h-6 text-emerald-100" />
          </div>
          <div>
            <h4 className="text-sm font-bold tracking-widest text-emerald-400 font-sans uppercase">SENTINEL PATH</h4>
            <p className="text-[10px] text-slate-500 font-mono">TRAFFIC MONITORING SYSTEM</p>
          </div>
        </div>
      </header>

      {/* Central Cover Content */}
      <main id="landing-main" className="z-10 w-full max-w-4xl mx-auto flex flex-col items-center text-center my-auto py-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex flex-col items-center"
        >
          {/* Lab identifier tag */}
          <span className="px-4 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-[11px] font-mono tracking-widest text-emerald-400 uppercase mb-4 shadow-inner">
            AI-POWERED INTELLIGENT TRAFFIC CONTROL SYSTEM
          </span>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white mb-6 leading-tight drop-shadow-md">
            AI-BASED TRAFFIC SIGNAL
            <span className="block mt-2 bg-gradient-to-r from-red-500 via-amber-400 to-emerald-400 bg-clip-text text-transparent">
              VIOLATION DETECTION
            </span>
          </h1>

          <div className="mb-12"></div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
            type="button"
            id="btn-proceed-to-portal"
            onClick={onNext}
            className="px-8 py-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-semibold flex items-center gap-3 shadow-xl shadow-emerald-900/30 ring-2 ring-emerald-500/20 active:outline-none transition-all duration-300"
          >
            <span>PROCEED TO OPERATOR PORTAL</span>
            <Eye className="w-5 h-5" />
          </motion.button>
        </motion.div>
      </main>

      {/* Footer Navigation Credits */}
      <footer id="landing-footer" className="z-10 w-full max-w-6xl mx-auto border-t border-slate-900 pt-6 flex flex-col sm:flex-row justify-between items-center text-[10px] text-slate-500">
        <span>&copy; May 2026 KIT Department of Computer Applications. All Rights Reserved.</span>
        <div className="flex gap-4 mt-2 sm:mt-0 font-mono">
          <span className="flex items-center gap-1"><Radio className="w-3 h-3 text-red-500 animate-pulse" /> NETWORK SECURED</span>
          <span className="flex items-center gap-1"><Activity className="w-3 h-3 text-emerald-500" /> ACTIVE SURVEILLANCE</span>
        </div>
      </footer>
      
    </div>
  );
}
