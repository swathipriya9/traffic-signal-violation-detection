import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, Radio, Activity, Video, Volume2, VolumeX, Eye, HelpCircle, 
  AlertOctagon, CheckCircle2, ShieldAlert, HeartPulse, UserCheck, 
  MapPin, Clock, RefreshCw, Sparkles, Send, BellRing, Terminal, ShieldX
} from 'lucide-react';
import { TrafficEvent, CameraNode, SecurityStatus } from '../types';
import { 
  playViolationBeep, playCrimeSiren, startEmergencySiren, stopEmergencySiren 
} from '../utils/audio';

interface DashboardPageProps {
  initialCameraEnabled: boolean;
  initialSirenEnabled: boolean;
  onLogout: () => void;
}

export default function DashboardPage({ 
  initialCameraEnabled, 
  initialSirenEnabled, 
  onLogout 
}: DashboardPageProps) {
  // Global Hardware control states
  const [cameraEnabled, setCameraEnabled] = useState(initialCameraEnabled);
  const [sirenEnabled, setSirenEnabled] = useState(initialSirenEnabled);
  const [isNightMode, setIsNightMode] = useState(false);
  const [activeSignal, setActiveSignal] = useState<'RED' | 'YELLOW' | 'GREEN'>('RED');
  
  // Stats
  const [violationsCount, setViolationsCount] = useState(5);
  const [jaywalkingCount, setJaywalkingCount] = useState(2);
  const [emergenciesCount, setEmergenciesCount] = useState(1);
  const [latency, setLatency] = useState(24);

  // Events & Logging
  const [events, setEvents] = useState<TrafficEvent[]>([]);
  const [selectedProofEvent, setSelectedProofEvent] = useState<TrafficEvent | null>(null);

  // Emergency Overlay state
  const [activeEmergency, setActiveEmergency] = useState<{
    id: string;
    title: string;
    details: string;
    node: string;
    type: 'COLLISION' | 'HEALTH_ISSUE' | 'CRIME_THREAT' | 'VIOLATION' | 'JAYWALKING';
  } | null>(null);

  // Gemini Assist State
  const [geminiAdvisory, setGeminiAdvisory] = useState<{
    assistantTip: string;
    instructions: string[];
    emergencyLevel: string;
  } | null>(null);
  const [isGeminiLoading, setIsGeminiLoading] = useState(false);

  // Telemetry logs
  const [telemetryLogs, setTelemetryLogs] = useState<string[]>([]);
  
  // Animation timers / canvas states
  const [pedestrianCrossingProgress, setPedestrianCrossingProgress] = useState(0);
  const [carCrossingProgress, setCarCrossingProgress] = useState(0);
  
  // Custom states for active simulated highlights in camera feeds
  const [camHighlight, setCamHighlight] = useState<{
    camId: string;
    type: 'violation' | 'jaywalk' | 'accident' | 'crime' | 'normal' | null;
    plate?: string;
  }>({ camId: '', type: null });

  // Load initial events from server-side database
  useEffect(() => {
    fetchEvents();
    
    // Auto Traffic Signal cycle interval (10 seconds loops)
    const signalInterval = setInterval(() => {
      setActiveSignal(prev => {
        if (prev === 'RED') return 'GREEN';
        if (prev === 'GREEN') return 'YELLOW';
        return 'RED';
      });
    }, 12000);

    // Heartbeat latency simulator
    const latencyInterval = setInterval(() => {
      setLatency(Math.floor(Math.random() * 8) + 18);
    }, 4000);

    // Minor visual cars loop inside cameras
    const animationInterval = setInterval(() => {
      setCarCrossingProgress(prev => (prev + 1.5) % 100);
      setPedestrianCrossingProgress(prev => (prev + 1) % 100);
    }, 100);

    // Telemetry noise logger
    addTelemetryLog("Sentinel surveillance server handshakes completed.");
    addTelemetryLog("CCTV Multi-cam feeds calibrated at 30 Frame/sec.");
    addTelemetryLog("Real-time Tesseract OCR stream listener is ready.");

    return () => {
      clearInterval(signalInterval);
      clearInterval(latencyInterval);
      clearInterval(animationInterval);
      stopEmergencySiren();
    };
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await fetch('/api/events');
      if (response.ok) {
        const data = await response.json();
        setEvents(data);
      }
    } catch (e) {
      console.warn("Failed to reach server-side logs, running mock history mode.", e);
    }
  };

  const addTelemetryLog = (msg: string) => {
    const time = new Date().toLocaleTimeString();
    setTelemetryLogs(prev => [`[${time}] ${msg}`, ...prev.slice(0, 18)]);
  };

  // Trigger Gemini Protocol generator from Server
  const getGeminiAdvisory = async (type: string, details: string, node: string) => {
    setIsGeminiLoading(true);
    setGeminiAdvisory(null);
    try {
      const res = await fetch('/api/gemini/assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventType: 'EMERGENCY', details, node })
      });
      if (res.ok) {
        const data = await res.json();
        setGeminiAdvisory(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeminiLoading(false);
    }
  };

  // Violation simulation triggering actions
  const triggerSignalViolation = async (isAutomated?: boolean, forcedCamId?: string) => {
    if (!cameraEnabled) {
      if (!isAutomated) {
        alert("Please activate the Vision Engine camera surveillance before running diagnostics.");
      }
      return;
    }
    
    if (activeSignalRef.current !== 'RED') {
      if (!isAutomated) {
        alert("Signal violation monitoring only detects infractions when the traffic signal is RED. Please wait for the signal to change to RED.");
      }
      return;
    }

    const availableCams = ['CAM-01', 'CAM-02', 'CAM-03', 'CAM-04'];
    const camId = forcedCamId || availableCams[Math.floor(Math.random() * availableCams.length)];

    const plates: Record<string, string> = {
      'CAM-01': 'TN-37-BY-8829',
      'CAM-02': 'TN-37-CZ-4412',
      'CAM-03': 'TN-37-AK-0051',
      'CAM-04': 'TN-37-DM-9104'
    };
    const nodes: Record<string, string> = {
      'CAM-01': 'CAM-01 (Crossing-A North)',
      'CAM-02': 'CAM-02 (Crossing-A South)',
      'CAM-03': 'CAM-03 (Hwy-B4 Interchange)',
      'CAM-04': 'CAM-04 (Main-St Pedestrian)'
    };
    const directions: Record<string, string> = {
      'CAM-01': 'CROSSING-A North',
      'CAM-02': 'CROSSING-A South',
      'CAM-03': 'HWY-B4 Interchange Exit',
      'CAM-04': 'MAIN-ST Pedestrian Crossing'
    };

    const targetPlate = plates[camId] || 'TN-37-BY-8829';
    const targetNodeName = nodes[camId] || 'CAM-01 (Crossing-A North)';
    const targetDir = directions[camId] || 'CROSSING-A North';
    
    setCamHighlight({ camId, type: 'violation', plate: targetPlate });
    addTelemetryLog(`WARNING: Red Signal overrun detected on ${targetDir}!`);
    addTelemetryLog(`📢 [CAMERA SHUTTER] Stop line crossing captured on ${camId}!`);

    if (sirenEnabled) {
      playViolationBeep();
    }

    try {
      const res = await fetch('/api/events/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'VIOLATION',
          title: 'SIGNAL JUMP',
          details: `Vehicle crossed stop line during active RED traffic signal on ${targetDir}.`,
          node: targetNodeName,
          plate: targetPlate
        })
      });
      if (res.ok) {
        const data = await res.json();
        setEvents(prev => [data.event, ...prev]);
        setViolationsCount(data.totals.violations);
      }
    } catch (e) {
      // Local fallback
      const newEvt: TrafficEvent = {
        id: `evt-${Math.floor(Math.random() * 900000) + 100000}`,
        timestamp: new Date().toLocaleTimeString(),
        type: 'VIOLATION',
        title: 'SIGNAL JUMP',
        details: `Vehicle crossed stop line during active RED traffic signal on ${targetDir}.`,
        node: targetNodeName,
        plate: targetPlate,
        resolved: false,
        timestampSeconds: Math.floor(Date.now() / 1000)
      };
      setEvents(prev => [newEvt, ...prev]);
      setViolationsCount(prev => prev + 1);
    }

    // Reset cctv screen highlights after 4 seconds
    setTimeout(() => {
      setCamHighlight({ camId: '', type: null });
    }, 6000);
  };

  const triggerJaywalkViolation = async (isAutomated?: boolean) => {
    if (!cameraEnabled) {
      if (!isAutomated) {
        alert("Please activate the Vision Engine camera surveillance before running diagnostics.");
      }
      return;
    }

    if (activeSignalRef.current !== 'RED') {
      if (!isAutomated) {
        alert("Jaywalking monitoring only detects infractions when the traffic signal is RED. Please wait for the signal to change to RED.");
      }
      return;
    }

    setCamHighlight({ camId: 'CAM-04', type: 'jaywalk' });
    addTelemetryLog("[PEDESTRIAN SENSING] Jaywalking monitoring active during RED SIGNAL.");
    addTelemetryLog("WARNING: Zebra crossing bypassing detected on MAIN-ST Pedestrian during RED SIGNAL!");

    if (sirenEnabled) {
      playViolationBeep();
    }

    try {
      const res = await fetch('/api/events/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'VIOLATION',
          title: 'JAYWALKING',
          details: 'Pedestrian bypassed zebra crossing lines into live roadways during RED traffic signal.',
          node: 'CAM-04 (Main-St Pedestrian)',
        })
      });
      if (res.ok) {
        const data = await res.json();
        setEvents(prev => [data.event, ...prev]);
        setJaywalkingCount(data.totals.jaywalking);
      }
    } catch (e) {
      const newEvt: TrafficEvent = {
        id: `evt-${Math.floor(Math.random() * 900000) + 100000}`,
        timestamp: new Date().toLocaleTimeString(),
        type: 'VIOLATION',
        title: 'JAYWALKING',
        details: 'Pedestrian bypassed zebra crossing lines into live roadways.',
        node: 'CAM-04 (Main-St Pedestrian)',
        resolved: false,
        timestampSeconds: Math.floor(Date.now() / 1000)
      };
      setEvents(prev => [newEvt, ...prev]);
      setJaywalkingCount(prev => prev + 1);
    }

    setTimeout(() => {
      setCamHighlight({ camId: '', type: null });
    }, 4000);
  };

  const triggerAccidentEmergency = (details: string, type: 'COLLISION' | 'HEALTH_ISSUE', isAutomated?: boolean) => {
    if (!cameraEnabled) {
      if (!isAutomated) {
        alert("Please activate the Vision Engine camera surveillance before running diagnostics.");
      }
      return;
    }

    const nodeLabel = type === 'COLLISION' ? 'CAM-03 (Hwy-B4 Interchange)' : 'CAM-04 (Main-St Pedestrian)';
    setCamHighlight({ camId: type === 'COLLISION' ? 'CAM-03' : 'CAM-04', type: 'accident' });
    
    addTelemetryLog(`ALERT: CRITICAL ROAD EMERGENCY - ${details}!`);
    addTelemetryLog("🚨 [SIREN ALERT] Broadcasting active physical siren alert sound globally!");
    addTelemetryLog("🚨 [HOSPITAL DIRECT LINK] Siren Alert dispatched to City Hospital emergency triage!");
    addTelemetryLog("📡 [TRAFFIC SERVER] Traffic server has broadcasted code-red Siren Alert protocol to all regional junctions!");
    
    const emergencyId = `evt-${Math.floor(Math.random() * 900000) + 100000}`;
    
    // Turn on active Emergency siren buzzer inside browser
    if (sirenEnabled) {
      startEmergencySiren();
    }

    setActiveEmergency({
      id: emergencyId,
      title: type === 'COLLISION' ? 'ACCIDENT OCCURRED' : 'MEDICAL EMERGENCY / PERSON FELL',
      details,
      node: nodeLabel,
      type
    });

    // Request safety response steps from our server proxy connected to Gemini 3.5 Flash!
    getGeminiAdvisory(type, details, nodeLabel);

    // Report emergency to server logs
    fetch('/api/events/report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'EMERGENCY',
        title: type === 'COLLISION' ? 'ACCIDENT OCCURRED' : 'MEDICAL EMERGENCY / PERSON FELL',
        details,
        node: nodeLabel
      })
    }).then(res => {
      if (res.ok) {
        res.json().then(data => {
          setEvents(prev => [data.event, ...prev]);
          setEmergenciesCount(data.totals.emergencies);
        });
      }
    }).catch(e => {
      // Fallback
      const newEvt: TrafficEvent = {
        id: emergencyId,
        timestamp: new Date().toLocaleTimeString(),
        type: 'EMERGENCY',
        title: type === 'COLLISION' ? 'ACCIDENT OCCURRED' : 'MEDICAL EMERGENCY / PERSON FELL',
        details,
        node: nodeLabel,
        resolved: false,
        timestampSeconds: Math.floor(Date.now() / 1000)
      };
      setEvents(prev => [newEvt, ...prev]);
      setEmergenciesCount(prev => prev + 1);
    });
  };

  const triggerCrimeThreat = async (isAutomated?: boolean) => {
    if (!cameraEnabled) {
      if (!isAutomated) {
        alert("Please activate the Vision Engine camera surveillance before running diagnostics.");
      }
      return;
    }

    setCamHighlight({ camId: 'CAM-02', type: 'crime' });
    addTelemetryLog("ALERT: Unlawful threat / violent coercion detected on CROSSING-A South!");

    if (sirenEnabled) {
      playCrimeSiren();
    }

    try {
      const res = await fetch('/api/events/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'CRIME',
          title: 'UNLAWFUL ASSEMBLY / THREAT',
          details: 'Pedestrian displaying physical threat or threatening behavior to another citizen.',
          node: 'CAM-02 (Crossing-A South)',
        })
      });
      if (res.ok) {
        const data = await res.json();
        setEvents(prev => [data.event, ...prev]);
      }
    } catch (e) {
      const newEvt: TrafficEvent = {
        id: `evt-${Math.floor(Math.random() * 900000) + 100000}`,
        timestamp: new Date().toLocaleTimeString(),
        type: 'CRIME',
        title: 'UNLAWFUL ASSEMBLY / THREAT',
        details: 'Unlawful assembly or threatening behavior.',
        node: 'CAM-02 (Crossing-A South)',
        resolved: false,
        timestampSeconds: Math.floor(Date.now() / 1000)
      };
      setEvents(prev => [newEvt, ...prev]);
    }

    setTimeout(() => {
      setCamHighlight({ camId: '', type: null });
    }, 4000);
  };

  // Clear Emergency Protocol Modal State
  const handleResolveEmergency = () => {
    stopEmergencySiren();
    if (activeEmergency) {
      addTelemetryLog(`Emergency incident resolved: ${activeEmergency.title}`);
      
      // Post resolution state updates to backend server
      fetch('/api/events/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: activeEmergency.id })
      }).then(() => fetchEvents());
    }
    setActiveEmergency(null);
    setGeminiAdvisory(null);
    setCamHighlight({ camId: '', type: null });
  };

  // Render a visual photo-capture overlay indicating a vehicle crossing the stop line under RED signal
  const renderViolationOverlay = (nodeId: string) => {
    if (camHighlight.camId !== nodeId || camHighlight.type !== 'violation') {
      return null;
    }

    const plateNumber = camHighlight.plate || 'TN-37-BY-8829';

    return (
      <div className="absolute inset-0 bg-[#05080e] flex divide-x divide-slate-800 z-10 animate-fade-in">
        {/* Left half: Schematic representation */}
        <div className="w-1/2 h-full opacity-40 relative flex items-center justify-center bg-[#05080e]/50">
          <span className="absolute top-1 left-1.5 text-[8px] text-slate-500 font-mono">SURVEILLANCE</span>
          <span className="w-4 h-4 rounded-full border border-red-500 text-red-500 flex items-center justify-center font-bold text-[8px] animate-ping">!</span>
        </div>
        {/* Right half: 📸 PHOTO METHOD ACTIVE CAPTURE */}
        <div className="w-1/2 h-full bg-[#0b121f] p-2 flex flex-col justify-between relative border-l border-red-500/30">
          <div className="absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-red-500 via-red-650 to-red-500 animate-pulse"></div>
          
          <div className="flex justify-between items-center text-[8px] font-mono leading-none border-b border-slate-800 pb-1">
            <span className="text-red-400 font-black animate-pulse flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-red-500 rounded-full inline-block animate-ping" />
              📸 PHOTO METHOD MONITORING
            </span>
          </div>

          <div className="flex-1 my-1 rounded border border-red-500/20 bg-slate-950/80 relative overflow-hidden flex flex-col justify-center items-center">
            {/* Simple wireframe vehicle inside bounding box */}
            <svg viewBox="0 0 100 50" className="w-[85%] h-[85%] text-red-500">
              <rect width="100%" height="50" fill="#020617" />
              {/* Red highlight target bounding box */}
              <rect x="15" y="10" width="70" height="30" fill="none" stroke="#ef4444" strokeWidth="1.2" className="animate-pulse" />
              <line x1="15" y1="10" x2="25" y2="10" stroke="#ef4444" strokeWidth="2" />
              <line x1="15" y1="10" x2="15" y2="20" stroke="#ef4444" strokeWidth="2" />
              
              {/* Car wireframe silhouette */}
              <rect x="25" y="18" width="50" height="15" rx="3" fill="#1e293b" stroke="#ef4444" strokeWidth="1" opacity="0.8" />
              <ellipse cx="38" cy="33" rx="5" ry="5" fill="#f8fafc" stroke="#ef4444" strokeWidth="0.75" />
              <ellipse cx="62" cy="33" rx="5" ry="5" fill="#f8fafc" stroke="#ef4444" strokeWidth="0.75" />
              
              <text x="21" y="27" fill="#ef4444" fontSize="5" fontFamily="monospace" fontWeight="bold">{plateNumber}</text>
            </svg>
            <span className="absolute bottom-1 right-1 text-[7px] bg-red-500 text-white px-1 rounded-sm leading-normal uppercase font-mono tracking-wider">
              STOP_LINE OVERRUN
            </span>
          </div>

          <div className="text-[8px] font-mono text-slate-400 leading-tight space-y-0.5">
            <div className="flex justify-between">
              <span>SCANNED:</span>
              <strong className="text-amber-400">{plateNumber}</strong>
            </div>
            <div className="flex justify-between font-bold">
              <span>SIREN STATUS:</span>
              <span className="text-red-400 animate-pulse">SIREN ALARM ACTIVE</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Keep up-to-date references of state variable values inside async loops to protect against React state closure scope staleness
  const cameraEnabledRef = useRef(cameraEnabled);
  const sirenEnabledRef = useRef(sirenEnabled);
  const activeEmergencyRef = useRef(activeEmergency !== null);
  const activeSignalRef = useRef(activeSignal);

  useEffect(() => {
    cameraEnabledRef.current = cameraEnabled;
  }, [cameraEnabled]);

  useEffect(() => {
    sirenEnabledRef.current = sirenEnabled;
  }, [sirenEnabled]);

  useEffect(() => {
    activeEmergencyRef.current = activeEmergency !== null;
  }, [activeEmergency]);

  useEffect(() => {
    activeSignalRef.current = activeSignal;
  }, [activeSignal]);

  // Automated System Background Road Monitoring Loops
  // Periodically triggers real-time roadway anomalies automatically simulating a live responsive camera guard
  useEffect(() => {
    const autoSimulatorInterval = setInterval(() => {
      // Direct inspection using Refs to maintain absolute accuracy of user engine toggles
      if (!cameraEnabledRef.current) return;
      if (activeEmergencyRef.current) return;

      const randomValue = Math.random();
      const isRedSignal = activeSignalRef.current === 'RED';

      if (isRedSignal) {
        // During RED signal: can trigger signal violations, jaywalking, or other emergencies
        if (randomValue < 0.50) {
          // Red Signal Overrun Detection (STOP LINE CROSSING) - MAIN detection priority on RED!
          triggerSignalViolation(true);
        } else if (randomValue < 0.75) {
          // Human jaywalk violation (only during RED signal)
          triggerJaywalkViolation(true);
        } else if (randomValue < 0.90) {
          // Roadway accident
          const accidentReports = [
            "Vehicle accident occurs on HWY-B4 lane intersection - active alerts sent.",
            "Roadway accident occurs on HWY-B4 exit ramp.",
            "Single vehicle crashed into safety guard-rail at HWY-B4 Interchange."
          ];
          const selectedDetail = accidentReports[Math.floor(Math.random() * accidentReports.length)];
          triggerAccidentEmergency(selectedDetail, 'COLLISION', true);
        } else {
          // Pedestrian health collapse
          const healthReports = [
            "Sidewalk pedestrian collapsed down on MAIN-ST walking pathway.",
            "Zebra-crossing pedestrian incapacitated under heavy clinical distress near CAM-04."
          ];
          const selectedDetail = healthReports[Math.floor(Math.random() * healthReports.length)];
          triggerAccidentEmergency(selectedDetail, 'HEALTH_ISSUE', true);
        }
      } else {
        // During YELLOW or GREEN signal: Strictly only trigger accidents or medical emergencies (NEVER signal violations or jaywalking)
        if (randomValue < 0.60) {
          // Roadway accident
          const accidentReports = [
            "Vehicle accident occurs on HWY-B4 lane intersection - active alerts sent.",
            "Roadway accident occurs on HWY-B4 exit ramp.",
            "Single vehicle crashed into safety guard-rail at HWY-B4 Interchange."
          ];
          const selectedDetail = accidentReports[Math.floor(Math.random() * accidentReports.length)];
          triggerAccidentEmergency(selectedDetail, 'COLLISION', true);
        } else {
          // Pedestrian health collapse
          const healthReports = [
            "Sidewalk pedestrian collapsed down on MAIN-ST walking pathway.",
            "Zebra-crossing pedestrian incapacitated under heavy clinical distress near CAM-04."
          ];
          const selectedDetail = healthReports[Math.floor(Math.random() * healthReports.length)];
          triggerAccidentEmergency(selectedDetail, 'HEALTH_ISSUE', true);
        }
      }
    }, 12000); // 12 seconds monitoring interval sweeps to sync perfectly with 12 seconds traffic light status loops

    return () => {
      clearInterval(autoSimulatorInterval);
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#070b13] text-slate-100 flex flex-col font-sans select-none relative">
      
      {/* Dynamic Header navigation controls */}
      <header id="dashboard-header" className="bg-[#0b111e]/90 border-b border-slate-800 px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4 sticky top-0 z-20 backdrop-blur">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-orange-600 flex items-center justify-center font-bold text-white tracking-tighter">
            S
          </div>
          <div>
            <h1 className="text-sm font-extrabold tracking-wider text-white uppercase flex items-center gap-2">
              SENTINEL PATH <span className="text-[10px] bg-slate-800 text-slate-400 font-mono px-1.5 py-0.5 rounded">SURVEILLANCE SYS V3.4</span>
            </h1>
            <p className="text-[10px] text-emerald-500 font-mono font-semibold flex items-center gap-1.5 mt-0.5">
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping inline-block"></span>
              FEDERAL SECURE ROADWAY TRANSIT ACCESS PORTAL
            </p>
          </div>
        </div>

        {/* Global Active Traffic Light Status HUD */}
        <div className="flex items-center gap-6 bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-800">
          <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase">Junction Light Status:</span>
          
          <div className="flex gap-2.5 items-center">
            {/* Red Light */}
            <div className="flex flex-col items-center">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shadow transition-all duration-300 ${
                activeSignal === 'RED' ? 'bg-red-500 shadow-red-900/80 scale-110 border-2 border-white' : 'bg-red-950/60 opacity-40'
              }`}>
                <span className="text-[8px] font-bold text-white">R</span>
              </div>
            </div>
            
            {/* Yellow Light */}
            <div className="flex flex-col items-center">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shadow transition-all duration-300 ${
                activeSignal === 'YELLOW' ? 'bg-yellow-500 shadow-yellow-900/80 scale-110 border-2 border-white' : 'bg-yellow-950/60 opacity-40'
              }`}>
                <span className="text-[8px] font-bold text-slate-950">Y</span>
              </div>
            </div>

            {/* Green Light */}
            <div className="flex flex-col items-center">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shadow transition-all duration-300 ${
                activeSignal === 'GREEN' ? 'bg-emerald-500 shadow-emerald-950 scale-110 border-2 border-white' : 'bg-emerald-950/60 opacity-40'
              }`}>
                <span className="text-[8px] font-bold text-white">G</span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Controls Header */}
        <div className="flex items-center gap-3">
          {/* Day / Night surveillance toggle */}
          <button
            type="button"
            id="btn-toggle-day-night"
            onClick={() => {
              setIsNightMode(!isNightMode);
              addTelemetryLog(`Switched surveillance feeds to ${!isNightMode ? 'Thermal InfraRed Night' : 'TrueColor HD Day'} mode.`);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono border transition-all cursor-pointer flex items-center gap-1.5 ${
              isNightMode 
              ? 'bg-indigo-950/40 border-indigo-500/30 text-indigo-300 hover:bg-indigo-900/40' 
              : 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300 hover:bg-emerald-900/40'
            }`}
          >
            {isNightMode ? (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>NIGHT MODE (IR active)</span>
              </>
            ) : (
              <>
                <Eye className="w-3.5 h-3.5" />
                <span>DAY MODE (HD truecolor)</span>
              </>
            )}
          </button>

          {/* Siren Alert global control */}
          <button
            type="button"
            id="btn-toggle-siren-hardware"
            onClick={() => {
              setSirenEnabled(!sirenEnabled);
              addTelemetryLog(`Hardware Speaker Siren ${!sirenEnabled ? 'ENABLED' : 'MUTED'} globally.`);
              if (sirenEnabled) stopEmergencySiren();
            }}
            className={`p-2 rounded-lg border cursor-pointer transition-all ${
              sirenEnabled 
              ? 'bg-amber-950/40 border-amber-500/30 text-amber-400 hover:bg-amber-900/40' 
              : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-slate-400'
            }`}
            title={sirenEnabled ? "Siren Alert Audibles Enabled" : "Siren Alert Audibles Muted"}
          >
            {sirenEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            type="button"
            id="btn-logout"
            onClick={onLogout}
            className="px-3 py-1.5 bg-slate-900 dark:bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-400 hover:text-white cursor-pointer transition-colors"
          >
            DISCONNECT
          </button>
        </div>
      </header>

      {/* Main Flex Work Area */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        
        {/* LANDING LEFT SIDEBAR PANEL - Operator Stats */}
        <aside id="dashboard-left-sidebar" className="w-full lg:w-72 bg-[#080d19]/95 border-r border-slate-900 p-5 flex flex-col gap-6 overflow-y-auto">
          
          {/* STATS HIGHLIGHT */}
          <div>
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800 pb-2 mb-3">
              Operator Monitoring stats
            </h3>
            
            <div className="grid grid-cols-2 lg:grid-cols-1 gap-3 font-mono">
              {/* Traffic Violations */}
              <div className="bg-slate-900/55 p-3 rounded-xl border border-slate-800/80">
                <span className="text-[9px] text-slate-500 uppercase font-semibold block">Stop Line Violations</span>
                <span id="stat-violations-count" className="text-2xl font-extrabold text-red-500 mt-1 block">
                  {violationsCount}
                </span>
              </div>

              {/* Jaywalking */}
              <div className="bg-slate-900/55 p-3 rounded-xl border border-slate-800/80">
                <span className="text-[9px] text-slate-500 uppercase font-semibold block">Jaywalking Detected</span>
                <span id="stat-jaywalk-count" className="text-2xl font-extrabold text-amber-500 mt-1 block">
                  {jaywalkingCount}
                </span>
              </div>

              {/* Emergency Cases */}
              <div className="bg-slate-900/55 p-3 rounded-xl border border-slate-800/80">
                <span className="text-[9px] text-slate-500 uppercase font-semibold block">Emergency Alerts</span>
                <span id="stat-emergencies-count" className="text-2xl font-extrabold text-red-400 mt-1 block">
                  {emergenciesCount}
                </span>
              </div>

              {/* Latency / Active Info */}
              <div className="bg-slate-900/55 p-3 rounded-xl border border-slate-800/80">
                <span className="text-[9px] text-slate-500 uppercase font-semibold block">System Latency</span>
                <span className="text-xs text-slate-300 font-bold mt-1 inline-flex items-center gap-1.5 uppercase">
                  {latency}ms <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse inline-block" />
                </span>
              </div>
            </div>
          </div>

          {/* EMERGENCY DIRECT PATH LINES */}
          <div>
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800 pb-2 mb-3">
              Emergency Direct Lines
            </h3>

            <div className="space-y-2 text-xs font-mono">
              {/* Police */}
              <div className="p-3 bg-[#0a101f]/70 rounded-xl border border-slate-900 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${activeEmergency?.type === 'CRIME_THREAT' || activeEmergency?.type === 'COLLISION' || activeEmergency?.type === 'VIOLATION' || activeEmergency?.type === 'JAYWALKING' ? 'bg-red-500 animate-ping' : 'bg-emerald-500'}`} />
                  <span className="font-semibold text-slate-300">Police Station B</span>
                </div>
                <span className="text-[9px] text-slate-500 font-bold uppercase">Connected</span>
              </div>

              {/* General Hospital */}
              <div className="p-3 bg-[#0a101f]/70 rounded-xl border border-slate-900 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${activeEmergency?.type === 'HEALTH_ISSUE' || activeEmergency?.type === 'COLLISION' ? 'bg-red-500 animate-ping' : 'bg-emerald-500'}`} />
                  <span className="font-semibold text-slate-300">City Hospital</span>
                </div>
                <span className="text-[9px] text-slate-500 font-bold uppercase">Connected</span>
              </div>

              {/* Cabin Intercom Walkie Talkie */}
              <div className="p-3 bg-[#0a101f]/70 rounded-xl border border-slate-900 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${activeEmergency ? 'bg-orange-500 animate-pulse' : 'bg-emerald-500'}`} />
                  <span className="font-semibold text-slate-300">Cabin Intercom</span>
                </div>
                <span className="text-[9px] text-slate-500 font-bold uppercase">Broadcast Cabin</span>
              </div>
            </div>
          </div>

          {/* EDGE SURVEILLANCE GUARD SWITCHES */}
          <div>
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800 pb-2 mb-3">
              Node Configuration
            </h3>

            <div className="space-y-3 pt-1">
              <label className="flex items-center justify-between text-xs text-slate-400 cursor-pointer">
                <span>Active Camera Video Inputs</span>
                <input 
                  type="checkbox" 
                  checked={cameraEnabled} 
                  onChange={() => {
                    setCameraEnabled(!cameraEnabled);
                    addTelemetryLog(`Camera Surveillance feeds globally ${!cameraEnabled ? 'ENABLED' : 'DISABLED'}`);
                  }}
                  className="rounded border-slate-800 text-emerald-500 focus:ring-emerald-500 focus:ring-opacity-20"
                />
              </label>

              <div className="p-3.5 bg-slate-900 border border-slate-850 rounded-xl text-[11px] leading-relaxed text-slate-500 font-mono">
                System automatically patrols the visible road lanes. Violations logged in UTC standard database.
              </div>
            </div>
          </div>

          {/* EXAMINER LOG OUT BUTTON */}
          <div className="mt-auto pt-6 border-t border-slate-900 text-center">
            <span className="text-[10px] text-slate-600 font-mono tracking-wider block">
              COIMBATORE DIVISION &bull; SENTINEL V3.4
            </span>
          </div>

        </aside>

        {/* CENTRAL CCTV CAMERA FEED GRID AND OVERRIDES */}
        <main className="flex-1 p-5 flex flex-col gap-5 overflow-y-auto bg-[#05080e] relative">
          
          {/* Centralized Emergency Protocol overlay restricted to camera area, matching the second photo */}
          <AnimatePresence>
            {activeEmergency && (
              <div id="emergency-protocol-overlay" className="absolute inset-0 bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-4 z-30">
                <motion.div
                  initial={{ scale: 0.95, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.95, opacity: 0 }}
                  className="bg-[#0b0c10] border border-red-500/30 rounded-2xl p-6 max-w-sm w-full text-center relative shadow-[0_0_40px_rgba(239,68,68,0.3)] flex flex-col gap-5"
                >
                  <div className="flex flex-col items-center">
                    <div className="w-14 h-14 bg-red-650/10 border border-red-500/40 text-red-500 rounded-full flex items-center justify-center mb-2 animate-pulse">
                      <AlertOctagon className="w-7 h-7" />
                    </div>
                    <h2 className="text-base font-bold tracking-widest text-white uppercase font-sans">
                      {activeEmergency.type === 'VIOLATION' 
                        ? 'STOP LINE VIOLATION' 
                        : activeEmergency.type === 'JAYWALKING' 
                        ? 'CROSSING INFRACTION' 
                        : 'EMERGENCY PROTOCOL'}
                    </h2>
                    <p className="text-[11px] text-slate-400 italic font-mono mt-1 text-center px-1">
                      {activeEmergency.details}
                    </p>
                  </div>

                  {/* Gemini Smart Advisory Guidance Section */}
                  <div className="bg-slate-950/80 rounded-xl border border-slate-900 p-3.5 text-left font-mono">
                    <div className="flex items-center gap-2 mb-2 border-b border-slate-900 pb-1.5 justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
                        <span className="text-[9px] font-bold text-slate-300 tracking-wider">SECURE SENTINEL PROTOCOL</span>
                      </div>
                      <span className="text-[7px] text-zinc-500 uppercase">GEMINI AUTO-GUIDE</span>
                    </div>
                    {isGeminiLoading ? (
                      <div className="space-y-2 py-1">
                        <div className="h-2.5 bg-slate-900 rounded animate-pulse w-3/4"></div>
                        <div className="h-2.5 bg-slate-900 rounded animate-pulse w-5/6"></div>
                      </div>
                    ) : geminiAdvisory ? (
                      <div className="space-y-2">
                        <p className="text-[9px] text-amber-400 leading-normal font-semibold">
                          &gt; {geminiAdvisory.assistantTip}
                        </p>
                        <div className="text-[8px] text-slate-400 space-y-1 leading-relaxed">
                          {geminiAdvisory.instructions.slice(0, 3).map((inst, idx) => (
                            <div key={idx} className="flex gap-1.5 items-start">
                              <span className="text-red-500 font-bold">•</span>
                              <span>{inst}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <p className="text-[8px] text-slate-500">Formulating active response guidelines from guard server...</p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-3 font-mono text-[9px] tracking-wider my-0.5">
                    <div className="p-2 bg-red-950/20 border border-red-500/20 rounded-lg text-red-500 font-bold uppercase text-center flex items-center justify-center">
                      POLICE: ALERTED
                    </div>
                    <div className="p-2 bg-red-950/20 border border-red-500/20 rounded-lg text-red-500 font-bold uppercase text-center flex items-center justify-center">
                      {activeEmergency.type === 'VIOLATION' || activeEmergency.type === 'JAYWALKING' 
                        ? 'FINE FILED' 
                        : 'MED_UNIT: ALERTED'}
                    </div>
                  </div>

                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    id="btn-resolve-emergency"
                    onClick={handleResolveEmergency}
                    className="w-full py-2.5 rounded-xl text-[10px] font-bold bg-red-600 hover:bg-red-500 text-white cursor-pointer transition-colors shadow-md shadow-red-950/50 uppercase tracking-widest"
                  >
                    RESOLVE & CLEAR SCAN
                  </motion.button>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          {/* DYNAMIC SYSTEM SECURITY STATUS & TRAFFIC FLOW BANNER */}
          <div id="traffic-status-banner" className="w-full">
            {!activeEmergency && (!camHighlight.camId || camHighlight.type === 'normal') ? (
              <div className="bg-emerald-950/25 border border-emerald-500/30 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-emerald-400 font-mono shadow-[0_0_20px_rgba(16,185,129,0.06)]">
                <div className="flex items-center gap-3">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                  </span>
                  <div>
                    <span className="text-xs font-black uppercase tracking-wider block">STATE LEVEL: SECURITAS NOMINAL</span>
                    <span className="text-[10px] text-emerald-500/90 font-medium uppercase mt-0.5 block">
                      ALL ROADWAY CHANNELS STABLE &bull; <strong className="text-white">TRAFFIC FLOW IS NORMAL</strong>
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-[9px] bg-emerald-950/50 border border-emerald-500/20 text-emerald-400 px-3 py-1 rounded-md">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>SECURE JUNCTION GUARDIAN READY</span>
                </div>
              </div>
            ) : (
              <div className="bg-red-950/35 border border-red-500/40 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-red-400 font-mono shadow-[0_0_20px_rgba(239,68,68,0.1)]">
                <div className="flex items-center gap-3">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                  </span>
                  <div>
                    <span className="text-xs font-black uppercase tracking-wider block">SECURITY OVERRIDE DETECTED</span>
                    <span className="text-[10px] text-red-350 font-medium uppercase mt-0.5 block">
                      ACTIVE VIOLATION OR ROAD HAZARD IN PROGRESS &bull; <strong className="text-white">PROCEED WITH EXTREME CAUTION</strong>
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-[9px] bg-red-950/50 border border-red-500/20 text-red-400 px-3 py-1 rounded-md animate-pulse">
                  <AlertOctagon className="w-3.5 h-3.5 text-red-500" />
                  <span>ALERT ACTIVE</span>
                </div>
              </div>
            )}
          </div>
          
          {/* CAMERA FEED GRID - Replicating Figure 9.2.4 */}
          <div id="cctv-grid-container" className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* CAMERA FEED 1: Crossing-A North */}
            <div id="cam-feed-node-1" className={`bg-slate-950 rounded-xl overflow-hidden border relative flex flex-col ${
              camHighlight.camId === 'CAM-01' ? 'border-orange-500 ring-2 ring-orange-950 shadow-[0_0_20px_rgba(249,115,22,0.15)]' : 'border-slate-800'
            }`}>
              {/* Vision HUD Overlay text information */}
              <div className="p-2.5 bg-black/70 backdrop-blur-sm border-b border-slate-900 flex justify-between items-center text-[10px] font-mono z-10">
                <span className="text-slate-300 font-bold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  CROSSING-A: NORTH
                  <span className="text-emerald-500/85 font-semibold text-[9px] ml-2">FPS: 60 | LAT: 12ms | NV_MODE: ON</span>
                </span>
                <span className="text-slate-500 font-semibold uppercase">NODE: CAM-01</span>
              </div>

              {/* Feed simulation radar map */}
              <div className="aspect-video w-full relative flex items-center justify-center overflow-hidden h-44 bg-[#05080e] transition-all duration-300">
                {!cameraEnabled ? (
                  <div className="text-center font-mono text-xs flex flex-col items-center gap-2 leading-relaxed text-slate-600">
                    <ShieldX className="w-6 h-6 text-slate-600" />
                    <span>CCTV CAMERA OFFLINE<br/>Vision Engine interface is disconnected</span>
                  </div>
                ) : (
                  <>
                    {/* Futuristic surveillance radar mesh overlay */}
                    <svg viewBox="0 0 350 200" className="w-full h-full absolute inset-0 text-emerald-500 select-none">
                      <defs>
                        <pattern id="radarGrid-1" width="20" height="20" patternUnits="userSpaceOnUse">
                          <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#10b981" strokeWidth="0.5" opacity="0.04" />
                        </pattern>
                      </defs>
                      <rect width="100%" height="100%" fill="url(#radarGrid-1)" />

                      {/* Concentric targets crosshairs */}
                      <circle cx="175" cy="100" r="45" fill="none" stroke="#10b981" strokeWidth="0.5" strokeDasharray="3,3" opacity="0.12" />
                      <circle cx="175" cy="100" r="80" fill="none" stroke="#10b981" strokeWidth="0.5" strokeDasharray="5,5" opacity="0.08" />
                      <circle cx="175" cy="100" r="115" fill="none" stroke="#10b981" strokeWidth="0.5" strokeDasharray="1,6" opacity="0.06" />

                      <line x1="0" y1="100" x2="350" y2="100" stroke="#10b981" strokeWidth="0.5" opacity="0.1" />
                      <line x1="175" y1="0" x2="175" y2="200" stroke="#10b981" strokeWidth="0.5" opacity="0.1" />

                      {/* Radar Scanning sweep lines */}
                      <line 
                        x1="175" 
                        y1="100" 
                        x2={175 + 130 * Math.cos((carCrossingProgress * 2 * Math.PI) / 100)} 
                        y2={100 + 130 * Math.sin((carCrossingProgress * 2 * Math.PI) / 100)} 
                        stroke="#10b981" 
                        strokeWidth="1" 
                        opacity="0.12" 
                      />

                      {/* Corner crop target frames */}
                      <g opacity="0.18">
                        <path d="M 40 30 L 55 30 M 40 30 L 40 45" stroke="#10b981" strokeWidth="1" fill="none" />
                        <path d="M 310 30 L 295 30 M 310 30 L 310 45" stroke="#10b981" strokeWidth="1" fill="none" />
                        <path d="M 40 170 L 55 170 M 40 170 L 40 155" stroke="#10b981" strokeWidth="1" fill="none" />
                        <path d="M 310 170 L 295 170 M 310 170 L 310 155" stroke="#10b981" strokeWidth="1" fill="none" />
                      </g>

                      {/* Target telemetry markers */}
                      <g opacity="0.4" className="font-mono">
                        <rect x="75" y="65" width="14" height="14" fill="none" stroke="#10b981" strokeWidth="0.75" />
                        <text x="75" y="58" fill="#10b981" fontSize="5" fontFamily="monospace">TRK_01</text>
                        <rect x="230" y="115" width="16" height="16" fill="none" stroke="#10b981" strokeWidth="0.75" />
                        <text x="230" y="110" fill="#10b981" fontSize="5" fontFamily="monospace">TRK_04</text>
                      </g>
                    </svg>

                    {/* RED LIGHT SIGNAL OVERRUN FLAG OR WARNING EMBED */}
                    {renderViolationOverlay('CAM-01')}
                    {!(camHighlight.camId === 'CAM-01' && camHighlight.type === 'violation') && (
                      <div className="absolute top-2 right-2 px-2 py-0.5 bg-slate-900/80 backdrop-blur rounded border border-slate-800 text-[8px] font-mono flex items-center gap-1.5">
                        <span className={`w-1.5 h-1.5 rounded-full ${activeSignal === 'RED' ? 'bg-red-500' : activeSignal === 'YELLOW' ? 'bg-yellow-500' : 'bg-emerald-500'}`}></span>
                        SIGNAL: {activeSignal}
                      </div>
                    )}
                  </>
                )}
              </div>

              {/* Bottom statistics and scan status wrapper */}
              <div className="p-2.5 bg-black/70 border-t border-slate-900 flex justify-between items-center text-[10px] font-mono z-10">
                <div className="flex flex-col gap-0.5 text-left font-mono">
                  <span className="text-slate-400 font-bold text-[9px] flex items-center gap-1">
                    <Radio className="w-3 h-3 text-slate-500" />
                    HEAVY_TRANSIT
                  </span>
                  <span className="text-emerald-500 text-[9px] font-bold">OBJECT_COUNT: 6</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="bg-red-950/60 text-red-400 text-[9px] font-bold px-2 py-0.5 rounded border border-red-500/40 uppercase tracking-wider">
                    STOP_LINE_SCAN
                  </span>
                  <svg className="w-8 h-4 text-emerald-400 opacity-70" viewBox="0 0 30 10">
                    <path d="M0,5 L5,5 L7,1 L10,9 L12,2 L15,5 L30,5" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </div>
            </div>

            {/* CAMERA FEED 2: Crossing-A South */}
            <div id="cam-feed-node-2" className={`bg-slate-950 rounded-xl overflow-hidden border relative flex flex-col ${
              camHighlight.camId === 'CAM-02' ? 'border-violet-500 ring-2 ring-violet-950 shadow-[0_0_20px_rgba(139,92,246,0.15)]' : 'border-slate-800'
            }`}>
              <div className="p-2.5 bg-black/70 backdrop-blur-sm border-b border-slate-900 flex justify-between items-center text-[10px] font-mono z-10">
                <span className="text-slate-300 font-bold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  CROSSING-A: SOUTH
                  <span className="text-emerald-500/85 font-semibold text-[9px] ml-2">FPS: 60 | LAT: 12ms | NV_MODE: ON</span>
                </span>
                <span className="text-slate-500 font-semibold uppercase">NODE: CAM-02</span>
              </div>

              <div className="aspect-video w-full relative flex items-center justify-center overflow-hidden h-44 bg-[#05080e] transition-all duration-300">
                {!cameraEnabled ? (
                  <div className="text-center font-mono text-xs flex flex-col items-center gap-2 leading-relaxed text-slate-655">
                    <ShieldX className="w-6 h-6 text-slate-600" />
                    <span>CCTV CAMERA OFFLINE</span>
                  </div>
                ) : (
                  <>
                    <svg viewBox="0 0 350 200" className="w-full h-full absolute inset-0 text-emerald-500 select-none">
                      <defs>
                        <pattern id="radarGrid-2" width="20" height="20" patternUnits="userSpaceOnUse">
                          <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#10b981" strokeWidth="0.5" opacity="0.04" />
                        </pattern>
                      </defs>
                      <rect width="100%" height="100%" fill="url(#radarGrid-2)" />

                      <circle cx="175" cy="100" r="45" fill="none" stroke="#10b981" strokeWidth="0.5" strokeDasharray="3,3" opacity="0.12" />
                      <circle cx="175" cy="100" r="80" fill="none" stroke="#10b981" strokeWidth="0.5" strokeDasharray="5,5" opacity="0.08" />

                      <line x1="0" y1="100" x2="350" y2="100" stroke="#10b981" strokeWidth="0.5" opacity="0.1" />
                      <line x1="175" y1="0" x2="175" y2="200" stroke="#10b981" strokeWidth="0.5" opacity="0.1" />

                      <line 
                        x1="175" 
                        y1="100" 
                        x2={175 + 130 * Math.cos((pedestrianCrossingProgress * 2 * Math.PI) / 100)} 
                        y2={100 + 130 * Math.sin((pedestrianCrossingProgress * 2 * Math.PI) / 100)} 
                        stroke="#10b981" 
                        strokeWidth="1" 
                        opacity="0.12" 
                      />

                      <g opacity="0.4">
                        <rect x="110" y="80" width="18" height="18" fill="none" stroke="#10b981" strokeWidth="0.75" />
                        <text x="110" y="73" fill="#10b981" fontSize="5" fontFamily="monospace">TRK_02</text>
                      </g>
                    </svg>

                    {renderViolationOverlay('CAM-02')}
                    {camHighlight.camId === 'CAM-02' && camHighlight.type === 'crime' && (
                      <div className="absolute inset-0 bg-violet-950/20 backdrop-blur-[0.5px] flex items-center justify-center p-3 z-10">
                        <div className="border-[3px] border-[#a78bfa] bg-slate-950/95 px-5 py-3 rounded-lg shadow-[0_0_25px_rgba(167,139,250,0.35)] animate-pulse">
                          <span className="text-xs font-bold tracking-widest text-[#a78bfa] uppercase font-sans text-center block">
                            CRIME THREAT DETECTED
                          </span>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>

              <div className="p-2.5 bg-black/70 border-t border-slate-900 flex justify-between items-center text-[10px] font-mono z-10">
                <div className="flex flex-col gap-0.5 text-left font-mono">
                  <span className="text-slate-400 font-bold text-[9px] flex items-center gap-1">
                    <Radio className="w-3 h-3 text-slate-500" />
                    LOCAL_GRID
                  </span>
                  <span className="text-emerald-500 text-[9px] font-bold">OBJECT_COUNT: 3</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="bg-red-955/60 text-red-400 text-[9px] font-bold px-2 py-0.5 rounded border border-red-500/40 uppercase tracking-wider">
                    STOP_LINE_SCAN
                  </span>
                  <svg className="w-8 h-4 text-emerald-400 opacity-70" viewBox="0 0 30 10">
                    <path d="M0,5 L5,5 L7,1 L10,9 L12,2 L15,5 L30,5" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </div>
            </div>

            {/* CAMERA FEED 3: Hwy-B4 Interchange */}
            <div id="cam-feed-node-3" className={`bg-slate-950 rounded-xl overflow-hidden border relative flex flex-col ${
              camHighlight.camId === 'CAM-03' ? 'border-red-500 ring-2 ring-red-950 shadow-[0_0_20px_rgba(239,68,68,0.25)]' : 'border-slate-800'
            }`}>
              <div className="p-2.5 bg-black/70 backdrop-blur-sm border-b border-slate-900 flex justify-between items-center text-[10px] font-mono z-10">
                <span className="text-slate-300 font-bold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  HWY-04: INTERCHANGE
                  <span className="text-emerald-500/85 font-semibold text-[9px] ml-2">FPS: 60 | LAT: 12ms | NV_MODE: ON</span>
                </span>
                <span className="text-slate-500 font-semibold uppercase">NODE: CAM-03</span>
              </div>

              <div className="aspect-video w-full relative flex items-center justify-center overflow-hidden h-44 bg-[#05080e] transition-all duration-300">
                {!cameraEnabled ? (
                  <div className="text-center font-mono text-xs flex flex-col items-center gap-2 leading-relaxed text-slate-650">
                    <ShieldX className="w-6 h-6 text-slate-600" />
                    <span>CCTV CAMERA OFFLINE</span>
                  </div>
                ) : (
                  <>
                    <svg viewBox="0 0 350 200" className="w-full h-full absolute inset-0 text-emerald-500 select-none">
                      <defs>
                        <pattern id="radarGrid-3" width="20" height="20" patternUnits="userSpaceOnUse">
                          <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#10b981" strokeWidth="0.5" opacity="0.04" />
                        </pattern>
                      </defs>
                      <rect width="100%" height="100%" fill="url(#radarGrid-3)" />

                      <circle cx="175" cy="100" r="45" fill="none" stroke="#10b981" strokeWidth="0.5" strokeDasharray="3,3" opacity="0.12" />
                      <circle cx="175" cy="100" r="80" fill="none" stroke="#10b981" strokeWidth="0.5" strokeDasharray="5,5" opacity="0.08" />

                      <line x1="0" y1="100" x2="350" y2="100" stroke="#10b981" strokeWidth="0.5" opacity="0.1" />
                      <line x1="175" y1="0" x2="175" y2="200" stroke="#10b981" strokeWidth="0.5" opacity="0.1" />

                      <line 
                        x1="175" 
                        y1="100" 
                        x2={175 + 130 * Math.cos((carCrossingProgress * 2.3 * Math.PI) / 100)} 
                        y2={100 + 130 * Math.sin((carCrossingProgress * 2.3 * Math.PI) / 100)} 
                        stroke="#10b981" 
                        strokeWidth="1" 
                        opacity="0.12" 
                      />

                      <g opacity="0.4">
                        <rect x="220" y="70" width="16" height="16" fill="none" stroke="#10b981" strokeWidth="0.75" />
                        <text x="220" y="63" fill="#10b981" fontSize="5" fontFamily="monospace">TRK_03</text>
                      </g>
                    </svg>

                    {renderViolationOverlay('CAM-03')}
                    {camHighlight.camId === 'CAM-03' && camHighlight.type === 'accident' && (
                      <div className="absolute inset-0 bg-red-950/30 backdrop-blur-[0.5px] flex items-center justify-center p-3 z-10 animate-pulse">
                        <div className="border-[3px] border-red-500 bg-slate-950/95 px-5 py-3 rounded-lg shadow-[0_0_25px_rgba(239,68,68,0.4)] text-center">
                          <span className="text-xs font-bold tracking-widest text-red-500 uppercase font-sans text-center block">
                            ACCIDENT DETECTED
                          </span>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>

              <div className="p-2.5 bg-black/70 border-t border-slate-900 flex justify-between items-center text-[10px] font-mono z-10">
                <div className="flex flex-col gap-0.5 text-left font-mono">
                  <span className="text-slate-400 font-bold text-[9px] flex items-center gap-1">
                    <Radio className="w-3 h-3 text-slate-500" />
                    HEAVY_TRANSIT
                  </span>
                  <span className="text-emerald-500 text-[9px] font-bold">OBJECT_COUNT: 6</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="bg-red-950/60 text-red-400 text-[9px] font-bold px-2 py-0.5 rounded border border-red-500/40 uppercase tracking-wider">
                    STOP_LINE_SCAN
                  </span>
                  <svg className="w-8 h-4 text-emerald-400 opacity-70" viewBox="0 0 30 10">
                    <path d="M0,5 L5,5 L7,1 L10,9 L12,2 L15,5 L30,5" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </div>
            </div>

            {/* CAMERA FEED 4: Main-St Pedestrian */}
            <div id="cam-feed-node-4" className={`bg-slate-950 rounded-xl overflow-hidden border relative flex flex-col ${
              camHighlight.camId === 'CAM-04' ? 'border-amber-500 ring-2 ring-amber-950 shadow-[0_0_20px_rgba(245,158,11,0.15)]' : 'border-slate-800'
            }`}>
              <div className="p-2.5 bg-black/70 backdrop-blur-sm border-b border-slate-900 flex justify-between items-center text-[10px] font-mono z-10">
                <span className="text-slate-300 font-bold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  MAIN-ST: PEDESTRIAN
                  <span className="text-emerald-500/85 font-semibold text-[9px] ml-2">FPS: 60 | LAT: 12ms | NV_MODE: ON</span>
                </span>
                <span className="text-slate-500 font-semibold uppercase">NODE: CAM-04</span>
              </div>

              <div className="aspect-video w-full relative flex items-center justify-center overflow-hidden h-44 bg-[#05080e] transition-all duration-300">
                {!cameraEnabled ? (
                  <div className="text-center font-mono text-xs flex flex-col items-center gap-2 leading-relaxed text-slate-600">
                    <ShieldX className="w-6 h-6 text-slate-600" />
                    <span>CCTV CAMERA OFFLINE</span>
                  </div>
                ) : (
                  <>
                    <svg viewBox="0 0 350 200" className="w-full h-full absolute inset-0 text-emerald-500 select-none">
                      <defs>
                        <pattern id="radarGrid-4" width="20" height="20" patternUnits="userSpaceOnUse">
                          <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#10b981" strokeWidth="0.5" opacity="0.04" />
                        </pattern>
                      </defs>
                      <rect width="100%" height="100%" fill="url(#radarGrid-4)" />

                      <circle cx="175" cy="100" r="45" fill="none" stroke="#10b981" strokeWidth="0.5" strokeDasharray="3,3" opacity="0.12" />
                      <circle cx="175" cy="100" r="80" fill="none" stroke="#10b981" strokeWidth="0.5" strokeDasharray="5,5" opacity="0.08" />

                      <line x1="0" y1="100" x2="350" y2="100" stroke="#10b981" strokeWidth="0.5" opacity="0.1" />
                      <line x1="175" y1="0" x2="175" y2="200" stroke="#10b981" strokeWidth="0.5" opacity="0.1" />

                      <line 
                        x1="175" 
                        y1="100" 
                        x2={175 + 130 * Math.cos((pedestrianCrossingProgress * 2 * Math.PI) / 100)} 
                        y2={100 + 130 * Math.sin((pedestrianCrossingProgress * 2 * Math.PI) / 100)} 
                        stroke="#10b981" 
                        strokeWidth="1" 
                        opacity="0.12" 
                      />

                      <g opacity="0.4">
                        <rect x="80" y="110" width="14" height="14" fill="none" stroke="#10b981" strokeWidth="0.75" />
                        <text x="80" y="103" fill="#10b981" fontSize="5" fontFamily="monospace">TRK_06</text>
                      </g>
                    </svg>

                    {renderViolationOverlay('CAM-04')}
                    {camHighlight.camId === 'CAM-04' && camHighlight.type === 'jaywalk' && (
                      <div className="absolute inset-0 bg-amber-950/20 backdrop-blur-[0.5px] flex items-center justify-center p-3 z-10">
                        <div className="border-[3px] border-amber-500 bg-slate-950/95 px-5 py-3 rounded-lg shadow-[0_0_25px_rgba(245,158,11,0.35)] animate-pulse">
                          <span className="text-xs font-bold tracking-widest text-amber-500 uppercase font-sans text-center block">
                            JAYWALK DETECTION
                          </span>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>

              <div className="p-2.5 bg-black/70 border-t border-slate-900 flex justify-between items-center text-[10px] font-mono z-10">
                <div className="flex flex-col gap-0.5 text-left font-mono">
                  <span className="text-slate-400 font-bold text-[9px] flex items-center gap-1">
                    <Radio className="w-3 h-3 text-slate-500" />
                    LOCAL_GRID
                  </span>
                  <span className="text-emerald-500 text-[9px] font-bold">OBJECT_COUNT: 3</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="bg-red-955/60 text-red-400 text-[9px] font-bold px-2 py-0.5 rounded border border-red-500/40 uppercase tracking-wider">
                    STOP_LINE_SCAN
                  </span>
                  <svg className="w-8 h-4 text-emerald-400 opacity-70" viewBox="0 0 30 10">
                    <path d="M0,5 L5,5 L7,1 L10,9 L12,2 L15,5 L30,5" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
              </div>
            </div>

          </div>





        </main>

        {/* RIGHT SIDEBAR PANEL - Live Event Feed */}
        <aside id="dashboard-right-sidebar" className="w-full lg:w-80 bg-[#080d19]/90 border-l border-slate-900 p-5 flex flex-col gap-4 overflow-y-auto">
          <div className="flex justify-between items-center border-b border-slate-900 pb-3 mb-2">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300">
              Live Surveillance Feed
            </h3>
            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono uppercase">
              {events.length} logs
            </span>
          </div>

          {/* scrolling events stack */}
          <div className="flex-1 space-y-3 pr-1 overflow-x-hidden select-text text-left">
            <AnimatePresence initial={false}>
              {events.map((evt) => (
                <motion.div
                  key={evt.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  onClick={() => {
                    setSelectedProofEvent(evt);
                  }}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    evt.type === 'EMERGENCY' 
                    ? 'bg-red-950/10 hover:bg-red-950/20 border-red-500/20 hover:border-red-500/40 shadow-sm shadow-red-950/10' 
                    : evt.type === 'VIOLATION'
                    ? 'bg-amber-950/10 hover:bg-amber-950/20 border-amber-500/20 hover:border-amber-500/40'
                    : evt.type === 'CRIME'
                    ? 'bg-violet-950/10 hover:bg-violet-950/20 border-violet-500/10 hover:border-violet-500/35'
                    : 'bg-slate-900/60 hover:bg-slate-900/80 border-slate-800'
                  }`}
                >
                  <div className="flex justify-between items-start gap-2 mb-1.5 font-mono">
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                      evt.type === 'EMERGENCY' ? 'bg-red-900/30 text-red-400 border border-red-500/20' :
                      evt.type === 'VIOLATION' ? 'bg-amber-900/30 text-amber-400 border border-amber-500/20' :
                      evt.type === 'CRIME' ? 'bg-violet-900/30 text-violet-400 border border-violet-500/10' :
                      'bg-slate-800 text-slate-400'
                    }`}>
                      {evt.type}
                    </span>
                    <span className="text-[10px] text-slate-500">{evt.timestamp}</span>
                  </div>

                  <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wide">
                    {evt.title}
                  </h4>
                  <p className="text-[11px] text-slate-400 leading-normal mt-1 limit-2-lines">
                    {evt.details}
                  </p>

                  <div className="mt-3 pt-2.5 border-t border-slate-900 flex justify-between items-center text-[9px] text-slate-500 font-mono">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-2.5 h-2.5" /> {evt.node.split(' ')[0]}
                    </span>
                    {evt.plate && (
                      <span className="bg-slate-950 px-1 border border-slate-900 text-amber-400 text-[10px] leading-none py-0.5 font-mono rounded">
                        TESSERACT: {evt.plate}
                      </span>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </aside>

      </div>

      {/* Global emergency overlay removed and moved inside central panel */}

      {/* DETAILED VIOLATION PROOF INSPECTOR DIALOG */}
      <AnimatePresence>
        {selectedProofEvent && (
          <div id="violation-inspect-overlay" className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-45">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0b111e] border border-slate-800 rounded-2xl p-6 max-w-md w-full relative space-y-4"
            >
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <span className="text-xs font-mono text-amber-500 font-bold flex items-center gap-1">
                  <Shield className="w-3.5 h-3.5" /> VIOLATION PROOF AND EVIDENTIARY ANALYSIS
                </span>
                <span className="text-[10px] text-slate-500 font-mono">ID: {selectedProofEvent.id}</span>
              </div>

              {/* Simulated Captured vehicle cropping rendering */}
              <div className="aspect-video w-full rounded-xl bg-slate-950 border border-slate-900 flex flex-col justify-center items-center overflow-hidden relative">
                {/* SVG representing captured frame evidence */}
                <svg viewBox="0 0 200 120" className="w-full h-full text-slate-700">
                  <rect x="0" y="0" width="200" height="120" fill={isNightMode ? "#042013" : "#1a2230"} />
                  <ellipse cx="100" cy="60" rx="30" ry="14" fill="#ef4444" opacity="0.1" stroke="#ef4444" strokeWidth="2" strokeDasharray="3,3" />
                  
                  {/* Cropped Car silhouette */}
                  <rect x="85" y="48" width="30" height="16" rx="2" fill={selectedProofEvent.type === 'EMERGENCY' ? '#991b1b' : '#38bdf8'} />
                  
                  {/* License plate label proof */}
                  <rect x="90" y="65" width="20" height="6" fill="#facc15" />
                  
                  <line x1="0" y1="1" x2="200" y2="120" stroke="#ef4444" strokeWidth="1" strokeDasharray="1,2" />
                  <line x1="200" y1="1" x2="0" y2="120" stroke="#ef4444" strokeWidth="1" strokeDasharray="1,2" />
                </svg>

                {selectedProofEvent.plate && (
                  <div className="absolute inset-x-0 bottom-0 py-2.5 bg-slate-900/90 text-[10px] text-amber-400 font-mono font-bold text-center border-t border-slate-800 uppercase tracking-widest">
                    SCANNED LICENSE PLATE: {selectedProofEvent.plate}
                  </div>
                )}
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-semibold font-mono uppercase">Incident node:</span>
                  <span className="text-slate-200 font-mono">{selectedProofEvent.node}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-semibold font-mono uppercase">Incident log time:</span>
                  <span className="text-slate-200 font-mono">{selectedProofEvent.timestamp}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 font-semibold font-mono uppercase">Violation classification:</span>
                  <span className="text-slate-200 font-mono font-semibold uppercase">{selectedProofEvent.title}</span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed pt-2 border-t border-slate-900 font-mono text-left select-text">
                  <span className="text-slate-500 block mb-1 uppercase font-bold">Details:</span>
                  {selectedProofEvent.details}
                </p>
              </div>

              <div className="pt-4 flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    addTelemetryLog(`Downloaded safety violation infraction files for ${selectedProofEvent.id}`);
                    alert("Infraction evidence files package generated and downloaded successfully.");
                    setSelectedProofEvent(null);
                  }}
                  className="flex-1 py-2.5 rounded-lg text-xs font-semibold text-slate-150 bg-slate-800 hover:bg-slate-750 transition-colors uppercase cursor-pointer"
                >
                  Download Evidence Package
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedProofEvent(null)}
                  className="px-4 py-2.5 rounded-lg text-xs font-bold text-slate-400 hover:text-white bg-slate-900 border border-slate-800 transition-colors uppercase cursor-pointer"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
