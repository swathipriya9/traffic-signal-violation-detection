import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle, Eye, Volume2, ArrowRight, ShieldCheck, Video } from 'lucide-react';

interface ReadinessPageProps {
  onBack: () => void;
  onGrant: (cameraEnabled: boolean, sirenEnabled: boolean) => void;
}

export default function ReadinessPage({ onBack, onGrant }: ReadinessPageProps) {
  const [cameraEnabled, setCameraEnabled] = useState(true);
  const [sirenEnabled, setSirenEnabled] = useState(true);

  return (
    <div id="readiness-container" className="min-h-screen bg-[#070b13] flex flex-col justify-center items-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden select-none">
      
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-950/10 blur-3xl rounded-full"></div>

      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-md w-full space-y-8 bg-[#0d1424] p-8 sm:p-10 rounded-2xl border border-slate-800 shadow-2xl relative"
      >
        {/* Core Readiness Check */}
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 rounded-full bg-emerald-950 border border-emerald-500/30 flex items-center justify-center mb-5 shadow-[0_0_20px_rgba(16,185,129,0.1)]">
            <ShieldCheck className="w-8 h-8 text-emerald-400" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-white uppercase font-sans">
            SYSTEM READINESS
          </h2>
          <span className="text-xs text-[#94a3b8] block mt-1">
            Initialize hardware interfaces for Sentinel Path
          </span>
        </div>

        {/* Nodes checklist */}
        <div className="space-y-4 pt-4">
          
          {/* VISION ENGINE */}
          <div 
            id="card-readiness-vision"
            onClick={() => setCameraEnabled(!cameraEnabled)}
            className={`p-5 rounded-2xl border transition-all duration-200 cursor-pointer flex items-center justify-between ${
              cameraEnabled 
              ? 'bg-[#0f1d2f]/70 border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]' 
              : 'bg-[#090f1a] border-slate-900 opacity-60'
            }`}
          >
            <div className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                cameraEnabled ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-900 text-slate-500'
              }`}>
                <Video className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h4 className="text-sm font-semibold text-white uppercase tracking-wider font-sans">VISION ENGINE</h4>
                <p className="text-[11px] text-slate-400 mt-0.5">Access 360° road camera nodes for surveillance</p>
              </div>
            </div>
            <div className="flex-shrink-0 ml-3">
              <div className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${
                cameraEnabled ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-800'
              }`}>
                {cameraEnabled && <div className="w-2 h-2 rounded-full bg-slate-950" />}
              </div>
            </div>
          </div>

          {/* SIREN PROTOCOL */}
          <div 
            id="card-readiness-siren"
            onClick={() => setSirenEnabled(!sirenEnabled)}
            className={`p-5 rounded-2xl border transition-all duration-200 cursor-pointer flex items-center justify-between ${
              sirenEnabled 
              ? 'bg-[#0f1d2f]/70 border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]' 
              : 'bg-[#090f1a] border-slate-900 opacity-60'
            }`}
          >
            <div className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                sirenEnabled ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-900 text-slate-500'
              }`}>
                <Volume2 className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h4 className="text-sm font-semibold text-white uppercase tracking-wider font-sans">SIREN PROTOCOL</h4>
                <p className="text-[11px] text-slate-400 mt-0.5">Audio feedback for RED signal violations & emergencies</p>
              </div>
            </div>
            <div className="flex-shrink-0 ml-3">
              <div className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${
                sirenEnabled ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-800'
              }`}>
                {sirenEnabled && <div className="w-2 h-2 rounded-full bg-slate-950" />}
              </div>
            </div>
          </div>

        </div>

        {/* CTA */}
        <div className="pt-6 space-y-3">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="button"
            id="btn-grant-access"
            onClick={() => onGrant(cameraEnabled, sirenEnabled)}
            className="w-full py-4 rounded-xl text-sm font-semibold text-[#090f1a] bg-gradient-to-r from-emerald-400 to-teal-500 hover:from-emerald-300 hover:to-teal-400 flex items-center justify-center gap-2 cursor-pointer transition-all shadow-lg shadow-emerald-500/10 font-sans"
          >
            <span>GRANT FULL ACCESS</span>
            <ArrowRight className="w-4 h-4 ml-1" />
          </motion.button>

          <button
            type="button"
            id="btn-readiness-disconnect"
            onClick={onBack}
            className="w-full py-2 text-xs text-slate-500 hover:text-slate-300 font-mono transition-colors text-center cursor-pointer"
          >
            HARDWARE LINK SECURED | AUTHENTICATED OPERATOR: ADMIN
          </button>
        </div>

      </motion.div>
    </div>
  );
}
