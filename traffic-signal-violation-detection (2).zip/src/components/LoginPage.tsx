import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldAlert, User, KeyRound, AlertTriangle, Cpu } from 'lucide-react';

interface LoginPageProps {
  onBack: () => void;
  onSuccess: () => void;
}

export default function LoginPage({ onBack, onSuccess }: LoginPageProps) {
  const [username, setUsername] = useState('admin');
  const [accessKey, setAccessKey] = useState('sentinel');
  const [error, setError] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !accessKey.trim()) {
      setError('Please provide correct credentials for Sentinel Path.');
      return;
    }

    setIsAuthenticating(true);
    setError('');

    // Simulate server side authentication check
    setTimeout(() => {
      setIsAuthenticating(false);
      if (username.toLowerCase() === 'admin' && accessKey.toLowerCase() === 'sentinel') {
        onSuccess();
      } else {
        setError('Unauthorized Access Key credentials. Please contact the Traffic Admin.');
      }
    }, 700);
  };

  return (
    <div id="login-container" className="min-h-screen bg-[#070b13] flex flex-col justify-center items-center py-12 px-4 sm:px-6 lg:px-8 relative overflow-hidden select-none">
      
      {/* Visual background shapes */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-sky-950/20 blur-3xl rounded-full"></div>
      <div className="absolute top-20 right-20 w-48 h-48 bg-amber-500/5 blur-3xl rounded-full"></div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="max-w-md w-full space-y-8 bg-[#0d1424] p-8 sm:p-10 rounded-2xl border border-slate-800 shadow-2xl relative"
      >
        {/* Shield graphic */}
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 rounded-xl bg-orange-600/10 border border-orange-500/30 flex items-center justify-center mb-4 transition-all duration-300">
            <ShieldAlert className="w-8 h-8 text-orange-500" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-white uppercase">
            TRAFFIC SIGNAL VIOLATION
          </h2>
          <span className="text-[11px] font-mono tracking-widest text-[#94a3b8] block mt-1 uppercase">
            SENTINEL PATH | COMMAND AUTH V3.4
          </span>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div id="login-error-pane" className="p-3 bg-red-950/50 border border-red-500/30 rounded-lg flex items-center gap-2 text-xs text-red-100 font-mono">
              <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="space-y-4 rounded-md shadow-sm">
            {/* Operator parameter */}
            <div>
              <label htmlFor="input-operator-username" className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 font-mono">
                Operator Username (Admin)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-4 w-4 text-slate-500" />
                </div>
                <input
                  id="input-operator-username"
                  name="username"
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 bg-[#080d19] border border-slate-800 rounded-xl text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 text-sm font-mono transition-all duration-150"
                  placeholder="admin"
                />
              </div>
            </div>

            {/* Access key parameter */}
            <div>
              <label htmlFor="input-access-key" className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 font-mono">
                Access Key (Sentinel)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <KeyRound className="h-4 w-4 text-slate-500" />
                </div>
                <input
                  id="input-access-key"
                  name="accessKey"
                  type="password"
                  required
                  value={accessKey}
                  onChange={(e) => setAccessKey(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 bg-[#080d19] border border-slate-800 rounded-xl text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-orange-500/50 focus:border-orange-500 text-sm font-mono transition-all duration-150"
                  placeholder="sentinel"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3 pt-2">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              id="btn-initialize-center"
              disabled={isAuthenticating}
              className="group relative w-full py-3.5 px-4 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-500 hover:to-amber-400 focus:outline-none flex justify-center items-center gap-2 cursor-pointer transition-all duration-150 shadow-lg shadow-orange-900/20"
            >
              {isAuthenticating ? (
                <>
                  <Cpu className="w-4 h-4 animate-spin" />
                  <span>NEGOTIATING SERVER FLOWS...</span>
                </>
              ) : (
                <span>INITIALIZE COMMAND CENTER</span>
              )}
            </motion.button>

            <button
              type="button"
              id="btn-back-to-landing"
              onClick={onBack}
              className="text-xs text-slate-500 hover:text-slate-300 font-mono transition-colors py-1 cursor-pointer"
            >
              DECLINE & HALTED ACCESS
            </button>
          </div>
        </form>

        <div className="border-t border-slate-900 pt-4 text-center">
          <p className="text-[10px] text-slate-600 font-mono flex items-center justify-center gap-1">
            <span>SECURE PORTAL</span> &bull; <span>SYSTEM UNDER ACTIVE SURVEILLANCE</span>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
