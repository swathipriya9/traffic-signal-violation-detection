/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import LandingPage from './components/LandingPage';
import LoginPage from './components/LoginPage';
import ReadinessPage from './components/ReadinessPage';
import DashboardPage from './components/DashboardPage';
import { AppPhase } from './types';
import { unlockAudio } from './utils/audio';

export default function App() {
  const [phase, setPhase] = useState<AppPhase>('landing');
  const [cameraEnabled, setCameraEnabled] = useState(true);
  const [sirenEnabled, setSirenEnabled] = useState(true);

  const handleLandingNext = () => {
    unlockAudio();
    setPhase('login');
  };

  const handleLoginBack = () => {
    unlockAudio();
    setPhase('landing');
  };

  const handleLoginSuccess = () => {
    unlockAudio();
    setPhase('readiness');
  };

  const handleReadinessBack = () => {
    unlockAudio();
    setPhase('login');
  };

  const handleReadinessGrant = (camEnabled: boolean, srnEnabled: boolean) => {
    unlockAudio();
    setCameraEnabled(camEnabled);
    setSirenEnabled(srnEnabled);
    setPhase('dashboard');
  };

  const handleDashboardLogout = () => {
    setPhase('login');
  };

  return (
    <div className="w-full min-h-screen bg-slate-950 text-slate-100">
      {phase === 'landing' && (
        <LandingPage onNext={handleLandingNext} />
      )}
      
      {phase === 'login' && (
        <LoginPage 
          onBack={handleLoginBack} 
          onSuccess={handleLoginSuccess} 
        />
      )}

      {phase === 'readiness' && (
        <ReadinessPage 
          onBack={handleReadinessBack} 
          onGrant={handleReadinessGrant} 
        />
      )}

      {phase === 'dashboard' && (
        <DashboardPage 
          initialCameraEnabled={cameraEnabled}
          initialSirenEnabled={sirenEnabled}
          onLogout={handleDashboardLogout}
        />
      )}
    </div>
  );
}
