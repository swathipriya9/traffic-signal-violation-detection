// Web Audio API Synthesizer to play powerful, high-intensity functional siren and alarm alerts
// This allows us to play audio without loading heavy static files which might fail in sandboxes.

let audioCtx: AudioContext | null = null;
let sirenInterval: any = null;
let sirenOsc1: OscillatorNode | null = null;
let sirenOsc2: OscillatorNode | null = null;
let sirenLFO: OscillatorNode | null = null;
let sirenGain: GainNode | null = null;

function getAudioContext() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioCtx;
}

// Ensure the audio context is unlocked on user gestures
export function unlockAudio() {
  try {
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
  } catch (e) {
    console.warn("Could not unlock audio:", e);
  }
}

export function playViolationBeep() {
  try {
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
    
    // Play a dual-tone punchy high-intensity alarm burst
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gainNode = ctx.createGain();
    
    osc1.type = 'sawtooth';
    osc1.frequency.setValueAtTime(950, ctx.currentTime);
    
    osc2.type = 'square';
    osc2.frequency.setValueAtTime(955, ctx.currentTime); // Slightly offset for chorus
    
    gainNode.gain.setValueAtTime(0.35, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
    
    osc1.connect(gainNode);
    osc2.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    osc1.start();
    osc2.start();
    osc1.stop(ctx.currentTime + 0.4);
    osc2.stop(ctx.currentTime + 0.4);
  } catch (error) {
    console.warn("Failed to play violation beep:", error);
  }
}

export function playCrimeSiren() {
  try {
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
    
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gainNode = ctx.createGain();
    
    osc1.type = 'sawtooth';
    osc1.frequency.setValueAtTime(400, ctx.currentTime);
    osc1.frequency.linearRampToValueAtTime(1200, ctx.currentTime + 0.2);
    osc1.frequency.linearRampToValueAtTime(400, ctx.currentTime + 0.4);
    
    osc2.type = 'square';
    osc2.frequency.setValueAtTime(405, ctx.currentTime);
    osc2.frequency.linearRampToValueAtTime(1205, ctx.currentTime + 0.2);
    osc2.frequency.linearRampToValueAtTime(405, ctx.currentTime + 0.4);
    
    gainNode.gain.setValueAtTime(0.35, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.45);
    
    osc1.connect(gainNode);
    osc2.connect(gainNode);
    gainNode.connect(ctx.destination);
    
    osc1.start();
    osc2.start();
    osc1.stop(ctx.currentTime + 0.45);
    osc2.stop(ctx.currentTime + 0.45);
  } catch (error) {
    console.warn("Failed to play crime siren:", error);
  }
}

export function startEmergencySiren() {
  try {
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
    
    if (sirenInterval) return; // Already running
    
    // Create a robust master gain node for high volume sirens without clipping
    sirenGain = ctx.createGain();
    sirenGain.gain.setValueAtTime(0.40, ctx.currentTime); // High volume alert
    sirenGain.connect(ctx.destination);
    
    // Oscillator 1: Primary piercing sawtooth wave
    sirenOsc1 = ctx.createOscillator();
    sirenOsc1.type = 'sawtooth';
    sirenOsc1.frequency.setValueAtTime(650, ctx.currentTime);
    sirenOsc1.connect(sirenGain);
    
    // Oscillator 2: Complementary square wave for maximum acoustic noise
    sirenOsc2 = ctx.createOscillator();
    sirenOsc2.type = 'square';
    sirenOsc2.frequency.setValueAtTime(655, ctx.currentTime); // Thick chorus offset
    sirenOsc2.connect(sirenGain);
    
    sirenOsc1.start();
    sirenOsc2.start();
    
    // Rapid wailing siren sweeps using a high-frequency interval timer
    let timeFraction = 0;
    sirenInterval = setInterval(() => {
      if (!ctx || !sirenOsc1 || !sirenOsc2) return;
      
      // Fast pitch sweep wave simulating emergency vehicle siren horns (Yelp / Wail combo)
      // Generates a smooth sine-like cycle between 550 Hz and 1150 Hz
      const sweepIndex = Math.sin(timeFraction);
      const baseFreq = 850 + sweepIndex * 300; // Oscillates between 550 and 1150 Hz
      
      const nextTime = ctx.currentTime + 0.08;
      sirenOsc1.frequency.linearRampToValueAtTime(baseFreq, nextTime);
      sirenOsc2.frequency.linearRampToValueAtTime(baseFreq + 10, nextTime);
      
      timeFraction += 0.4;
    }, 80);
    
  } catch (error) {
    console.warn("Failed to start powerful emergency siren:", error);
  }
}

export function stopEmergencySiren() {
  if (sirenInterval) {
    clearInterval(sirenInterval);
    sirenInterval = null;
  }
  
  try {
    if (sirenOsc1) {
      sirenOsc1.stop();
      sirenOsc1.disconnect();
      sirenOsc1 = null;
    }
    if (sirenOsc2) {
      sirenOsc2.stop();
      sirenOsc2.disconnect();
      sirenOsc2 = null;
    }
    if (sirenLFO) {
      sirenLFO.stop();
      sirenLFO.disconnect();
      sirenLFO = null;
    }
    if (sirenGain) {
      sirenGain.disconnect();
      sirenGain = null;
    }
  } catch (e) {
    console.warn("Error stopping audio components:", e);
  }
}
