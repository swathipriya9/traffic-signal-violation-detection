export type AppPhase = 'landing' | 'login' | 'readiness' | 'dashboard';

export interface TrafficEvent {
  id: string;
  timestamp: string;
  type: 'VIOLATION' | 'EMERGENCY' | 'CRIME' | 'NORMAL';
  title: string;
  details: string;
  node: string; // e.g. CAM-01 (Crossing-A North)
  plate?: string; // Number plate scanned via simulated Tesseract OCR
  resolved: boolean;
  timestampSeconds: number;
}

export interface CameraNode {
  id: string;
  name: string;
  location: string;
  status: 'Active' | 'Inactive';
  vehicleCount: number;
}

export interface SecurityStatus {
  policeStream: 'Connected' | 'Disconnected' | 'Alerting';
  hospitalStream: 'Connected' | 'Disconnected' | 'Alerting';
  cabinIntercom: 'Idle' | 'Calling' | 'Broadcasting';
}
