import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory server state for simulations
const serverData = {
  violationsCount: 5,
  jaywalkingCount: 2,
  emergenciesCount: 0,
  events: [
    {
      id: "evt-01",
      timestamp: new Date(Date.now() - 3600000).toLocaleTimeString(),
      type: "VIOLATION",
      title: "SIGNAL JUMP",
      details: "Vehicle crossed stop line during RED traffic signal.",
      node: "CAM-01 (Crossing-A North)",
      plate: "TN-37-BY-8829",
      resolved: false,
      timestampSeconds: Math.floor((Date.now() - 3600000) / 1000)
    },
    {
      id: "evt-02",
      timestamp: new Date(Date.now() - 1800000).toLocaleTimeString(),
      type: "VIOLATION",
      title: "JAYWALKING",
      details: "Pedestrian crossed road outside the defined zebra landing strip.",
      node: "CAM-04 (Main-St Pedestrian)",
      plate: undefined,
      resolved: false,
      timestampSeconds: Math.floor((Date.now() - 1800000) / 1000)
    },
    {
      id: "evt-03",
      timestamp: new Date(Date.now() - 1200000).toLocaleTimeString(),
      type: "NORMAL",
      title: "HEAVY TRAFFIC NODE",
      details: "Node capacity exceeded standard 75% traffic limit status.",
      node: "CAM-03 (Hwy-B4 Interchange)",
      plate: undefined,
      resolved: true,
      timestampSeconds: Math.floor((Date.now() - 1200000) / 1000)
    }
  ]
};

// Lazy initialize Gemini API client to prevent crashes if key is omitted
let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key && key !== "MY_GEMINI_API_KEY") {
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
  }
  return aiClient;
}

// REST endpoints for logging violations and status checks
app.get("/api/status", (req, res) => {
  res.json({
    status: "Operational",
    system: "Sentinel Path Surveillance V3.4",
    uptime: process.uptime(),
    activeNodesCount: 4,
    violations: serverData.violationsCount,
    jaywalking: serverData.jaywalkingCount,
    emergencies: serverData.emergenciesCount,
    connections: {
      police: "Connected",
      hospital: "Connected",
      trafficCabin: "Active"
    }
  });
});

app.get("/api/events", (req, res) => {
  res.json(serverData.events);
});

app.post("/api/events/report", (req, res) => {
  const { type, title, details, node, plate } = req.body;
  
  const newEvent = {
    id: `evt-${Math.floor(Math.random() * 900000) + 100000}`,
    timestamp: new Date().toLocaleTimeString(),
    type: type || "VIOLATION",
    title: title || "RULES BREACHED",
    details: details || "Traffic rule violation logged automatically.",
    node: node || "CAM-01 (Crossing-A North)",
    plate: plate || undefined,
    resolved: false,
    timestampSeconds: Math.floor(Date.now() / 1000)
  };

  serverData.events.unshift(newEvent);
  
  // Update internal metrics
  if (type === "VIOLATION") {
    serverData.violationsCount++;
  } else if (type === "EMERGENCY") {
    serverData.emergenciesCount++;
  } else if (title?.toUpperCase()?.includes("JAYWALK")) {
    serverData.jaywalkingCount++;
  }

  res.status(201).json({ success: true, event: newEvent, totals: {
    violations: serverData.violationsCount,
    jaywalking: serverData.jaywalkingCount,
    emergencies: serverData.emergenciesCount
  }});
});

app.post("/api/events/resolve", (req, res) => {
  const { id } = req.body;
  const event = serverData.events.find(e => e.id === id);
  if (event) {
    event.resolved = true;
    res.json({ success: true, event });
  } else {
    res.status(404).json({ error: "Event not found" });
  }
});

// AI Safety Assist endpoint using Gemini API
app.post("/api/gemini/assist", async (req, res) => {
  const { eventType, details, node } = req.body;
  
  try {
    const ai = getAiClient();
    if (!ai) {
      // Fallback instruction if API Key isn't configured yet
      res.json({
        assistantTip: `[Sentinel AI Patrol Protocol] Dispatch local vehicle immediately to ${node || "the target road intersection"}. Deploy a secondary safety perimeter and notify local medical responders if an emergency is indicated.`,
        instructions: [
          "Secure the perimeter immediately around the vehicle/subject.",
          "Redirect local incoming lanes to avoid structural lane congestion.",
          "Broadcast a caution signal via the cabin walkie-talkie channel.",
          "Audit camera records for insurance claims evidence."
        ],
        emergencyLevel: eventType === "EMERGENCY" ? "CRITICAL" : "STANDARD"
      });
      return;
    }

    const prompt = `You are the Sentinel Road Safety Protocol AI for a real-time smart road junction system called "Sentinel Path".
We detected a security scenario:
- EVENT TYPE: ${eventType || "TRAFFIC INCIDENT"}
- LOCATION: ${node || "CAM-01 crossing"}
- DESCRIPTION: ${details || "Severe impact details"}.

Generate a high-level concise, structured security emergency plan for the operator. Provide your response strictly in the following JSON format as requested in the API schema. Do not output any markdown text blocks or code fences, output ONLY raw JSON:
{
  "assistantTip": "One sentence summary action guide",
  "instructions": ["Step 1 concise action", "Step 2 concise action", "Step 3 concise action"],
  "emergencyLevel": "CRITICAL" or "STANDARD"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json(parsed);

  } catch (error: any) {
    console.error("Gemini API error:", error);
    res.status(500).json({
      error: "Failed to consult Gemini model.",
      assistantTip: "Dispatcher Alert! Secure safety protocols immediately manually and clear lane blocks.",
      instructions: [
        "Enable hardware caution lights across the whole roadway.",
        "Signal emergency services using landline channels.",
        "Alert nearest traffic cabins instantly."
      ],
      emergencyLevel: eventType === "EMERGENCY" ? "CRITICAL" : "STANDARD"
    });
  }
});

// Vite middleware flow
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
